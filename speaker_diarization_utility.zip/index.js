const process = require('process');
const path = require('path');
const fetchp = require('node-fetch');
const admZip = require('adm-zip')
const fs = require('fs');
const request = require('superagent');

exports.speaker_diarization_utility = (data, context) => {
    const ALLOWED_APPLICATION_TYPES = ['application/x-zip-compressed']
    const ALLOWED_FORMATS = ['.zip']
    const file = data;

    var fileUtility = (() => {

        function _getFileName(completeAddr) {
            // split the address and look for extentions
            const fileNameArr = completeAddr.split('/');
            console.log(fileNameArr);
            const selectedFileName = fileNameArr.filter(entry => {
                if (ALLOWED_FORMATS.includes(path.extname(entry))) {
                    return entry;
                } else return false;
            });
            console.log('selected file name is ', selectedFileName);
            return selectedFileName;
        }

        function _createCloudUrlForFile(completeAddrToUse, bucketName) {
            // gs://test_diarization/dynamic_usersNew.wav
            // https://storage.cloud.google.com/echo_zoom_video/test%20folder/host_session_zip_folder.zip?authuser=1
            return `https://storage.cloud.google.com/${bucketName}/${completeAddrToUse}?authuser=1`
        }
        return {
            getFileName: _getFileName,
            createCloudUrl: _createCloudUrlForFile
        }
    })()
    console.log(`
    data recieved is ${JSON.stringify(file)} and content recieved is ${JSON.stringify(context)}`);
    // create an access gstore url for the zip file
    // use that url to unzip the file, and read the contents,
    // upload the contents with the same name as the folder in a new bucket called extracted_zoom_video_zips
    if (ALLOWED_APPLICATION_TYPES.includes(file.contentType)) {
        console.log('cwd is ', process.cwd());
        const fileName = fileUtility.getFileName(file.name)[0];
        console.log('fileName is ', fileName);
        const gcFileUrl = fileUtility.createCloudUrl(file.name, file.bucket);
        console.log('gcloud url is ', gcFileUrl);

        // extract it
        request(gcFileUrl)
        .pipe(fs.createWriteStream(fileName))
        .on('finsih', () => {

            console.log('finished downloading');
            var zip = new admZip(zipFile);
            console.log('start unzip');
            try {
                fs.mkdirSync(path.join(__dirname, 'custom_zip'));
                zip.extractEntryTo(path.join(__dirname, 'custom_zip'), '/', false, true);
                console.log('finished unzip');
            } catch(e) {console.log('error while reading the zip file', e)}
        });
        /* .then(res => res.buffer())
        .then(buffer => fileType(buffer))
        .then(type => { console.log('type details ', type)})
        .then(response => {
            console.log('recieved file as ', response);
        
        }).catch(error => {console.log('error while reading the zip file', error)}) */
    }
  };